# -*- coding: utf-8 -*-
"""
Created on Fri Nov  9 09:50:44 2018

@author: Shiv
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
plt.style.use('fivethirtyeight')
#%matplotlib inline

stock_data = pd.read_csv('data_sets/stock_data.csv', parse_dates=['Date'],index_col=['Date']).dropna()
benchmark_data = pd.read_csv('data_sets/benchmark_data.csv', parse_dates=['Date'],index_col=['Date']).dropna()

print('Stocks\n')     #Displaying the stock_data Information.
stock_data.info()

print('\nBenchmarks\n')      
benchmark_data.info()        #Displaying the benchmark_data Information.

stock_data.plot(subplots=True, title = 'Stock Data')

print(stock_data.describe())

benchmark_data.plot(title = 'S&P 500')

print(benchmark_data.describe())

#Here In the below step we can get Stock Returns using pct_change()
stock_returns = stock_data.pct_change()
stock_returns.plot()
print("Stock Returns:")
print(stock_returns.describe())

#Here In the below step we can get s&p 500 Returns using pct_change()
sp_returns = benchmark_data['S&P 500'].pct_change()
sp_returns.plot()
print("S & P 500 Returns:")
print(sp_returns.describe())

#Here We are calculating the Relative Performance between stock and S & P 
print("Excess Returns:")
excess_returns = stock_returns.sub(sp_returns,axis=0)
excess_returns.plot()
print(excess_returns.describe())


# calculate the mean of excess_returns 
avg_excess_return = excess_returns.mean()
print("Avg Excess return",avg_excess_return)
#avg_excess_return.plot.bar(title='Mean of the Return Difference')



# calculate the standard deviations
sd_excess_return = excess_returns.std()

# calculate the daily sharpe ratio
daily_sharpe_ratio = avg_excess_return.div(sd_excess_return)

# annualize the sharpe ratio
annual_factor = np.sqrt(252)
annual_sharpe_ratio = daily_sharpe_ratio.mul(annual_factor)

# plot the annualized sharpe ratio
annual_sharpe_ratio.plot.bar(title='Annualized Sharpe Ratio: Stocks vs S&P 500')